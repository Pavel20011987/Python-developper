from django.apps import AppConfig


class ResetPasswordAppConfig(AppConfig):
    name = 'reset_password_app'
