from django.apps import AppConfig


class GraphAppConfig(AppConfig):
    name = 'graph_app'
