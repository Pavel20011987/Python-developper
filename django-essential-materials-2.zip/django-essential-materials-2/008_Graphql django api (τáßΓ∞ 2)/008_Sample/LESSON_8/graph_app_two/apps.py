from django.apps import AppConfig


class GraphAppTwoConfig(AppConfig):
    name = 'graph_app_two'
