from django.apps import AppConfig


class WsgiCeleryConfig(AppConfig):
    name = 'wsgi_celery'
