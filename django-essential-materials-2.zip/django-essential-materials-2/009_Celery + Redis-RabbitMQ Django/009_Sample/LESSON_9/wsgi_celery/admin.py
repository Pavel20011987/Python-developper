from django.contrib import admin

from .models import Bot

admin.site.register(Bot)
