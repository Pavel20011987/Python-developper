counter = 0
while counter < 10:
    print(counter)

for element in range(10):
    print(element)

for element in range(5):
    if element == 3:
        continue
    print(element)

for element in range(5):
    if element == 3:
        break
