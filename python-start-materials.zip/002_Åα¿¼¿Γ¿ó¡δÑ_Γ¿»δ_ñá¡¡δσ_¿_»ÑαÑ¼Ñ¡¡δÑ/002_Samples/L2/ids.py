apples = 10
var_2 = 10000
print(id(apples))
print(id(var_2))
