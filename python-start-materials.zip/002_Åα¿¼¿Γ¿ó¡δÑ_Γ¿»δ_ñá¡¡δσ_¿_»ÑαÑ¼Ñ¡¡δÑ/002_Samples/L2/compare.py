a = 10
b = 5
c = a == b
print(c)

b = "apple"
b2 = "Apple"
compare_b_b2 = b == b2
print(compare_b_b2)
compare_b_b2_lower = b == b2.lower()
print(compare_b_b2_lower)
x = "apple" * 3 + "hello"
print(x)
