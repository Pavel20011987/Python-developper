a = "hello"
b = 'hello'
c = '''hello
world
and
hello
you'''
d = """hello
world
and
hello
you"""
print(a)
print(b)
print(c)
print(d)

s = "this is John's ball"
print(s)