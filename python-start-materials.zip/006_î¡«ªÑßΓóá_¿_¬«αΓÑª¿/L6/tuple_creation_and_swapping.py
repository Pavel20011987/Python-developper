a = (1, 2, 3, 4)
print(a)
a = (1, 2)
x, y = a
print(x)
print(y)
x, y = y, x
print(x)
print(y)
