a = [(1, 2, 3), (3, 4, 5)]
for first, second, third in a:
    print(first, second, third)
