a = {1, 2, 2, 3, 4, 4, 4, 4, 4, 4}
print(a)
a = {1, 2, 3, 4}
a.pop()
a.pop()
print(a)
a = {1, 2, 3}
a.discard(4)
a.discard(1)
print(a)
a = {1, 2, 3}
a.discard(4)
a.discard(1)