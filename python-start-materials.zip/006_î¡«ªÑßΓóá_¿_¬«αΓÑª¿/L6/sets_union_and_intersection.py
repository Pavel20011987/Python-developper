a = {1, 2, 3}
b = {3, 4, 5}
print(a.union(b))
print(a.intersection(b))