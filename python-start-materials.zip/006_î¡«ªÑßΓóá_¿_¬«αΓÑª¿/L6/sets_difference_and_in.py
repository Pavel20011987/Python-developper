a = {1, 2, 3, 4}
b = {3, 4}
print(b.difference(a))
a = {1, 3, 5, 2, 10}
print(10 in a)
