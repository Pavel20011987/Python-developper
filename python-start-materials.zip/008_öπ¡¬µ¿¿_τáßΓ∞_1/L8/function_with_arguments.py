def func(a, b, c):
    print(a + b + c)


func(4, 4, 4)
