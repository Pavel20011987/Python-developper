def get_string_length(string):
    return len(string)


string_a = "hello"
string_b = "bye"
len_a = get_string_length(string_a)
len_b = get_string_length(string_b)
print("Str a has", len_a, "characters")
print("Str b has", len_b, "characters")
