def print_value():
    print(2 + 2)


print(print_value)
print(print_value())
