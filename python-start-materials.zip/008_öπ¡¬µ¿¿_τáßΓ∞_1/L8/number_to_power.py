def power(value, value_power):
    if value_power >= 0:
        return value ** value_power


two_in_power_of_ten = power(2, -1)
print(two_in_power_of_ten)
