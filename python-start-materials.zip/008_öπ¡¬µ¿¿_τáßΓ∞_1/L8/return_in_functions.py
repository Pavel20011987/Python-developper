def function(a, b):
    return a + b


result = function(2, 5)
result2 = function(10, 45)
print(result)
print(result2)
