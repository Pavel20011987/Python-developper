value_str = "hello"
result = None if not value_str else value_str
another_way = value_str if value_str else None
