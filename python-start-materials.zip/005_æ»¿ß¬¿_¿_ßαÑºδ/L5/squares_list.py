my_list = [2, 4, 6, 8]
squares_list = []
for list_element in my_list:
    squares_list.append(list_element**2)
print(squares_list)