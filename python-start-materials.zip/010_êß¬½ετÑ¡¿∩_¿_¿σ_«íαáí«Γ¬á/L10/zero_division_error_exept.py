a = 10
b = 0

try:
    c = a / b
except:
    c = 0
    print("division on zero")
print(c)
