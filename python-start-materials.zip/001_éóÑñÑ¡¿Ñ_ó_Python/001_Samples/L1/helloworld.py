print("Hello world !")
