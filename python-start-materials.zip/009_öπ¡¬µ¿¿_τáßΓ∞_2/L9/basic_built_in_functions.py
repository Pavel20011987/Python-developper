my_list = [-35, 2, 3, 10]
print(len(my_list))  # 4 count of values in list
print(len("hello"))  # 5 count of chars in string
print(sum(my_list))  # -20 sum of values in list
print(max(my_list))  # 10 max of values in list
print(min(my_list))  # -35 min of values in list

print(sum(my_list) / len(my_list))  # -5.0 average of values in list
