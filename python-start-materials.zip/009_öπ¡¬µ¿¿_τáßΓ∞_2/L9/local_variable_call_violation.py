def function():
    x = 10
    print(x)


function()  # no error here

print(x)  # error
