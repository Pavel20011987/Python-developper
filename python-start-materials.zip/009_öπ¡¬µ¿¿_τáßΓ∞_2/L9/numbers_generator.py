def generate_numbers(n):
    for value in range(1, n + 1):
        print(value)


generate_numbers(10)  # 1 2 3 ... 10
