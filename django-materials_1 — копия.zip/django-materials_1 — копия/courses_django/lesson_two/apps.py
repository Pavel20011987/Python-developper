from django.apps import AppConfig


class LessonTwoConfig(AppConfig):
    name = 'lesson_two'
