from django.apps import AppConfig


class LessonSixthConfig(AppConfig):
    name = 'lesson_sixth'
