from django.apps import AppConfig


class LessonFifthConfig(AppConfig):
    name = 'lesson_fifth'
