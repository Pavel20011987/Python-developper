from django.contrib import admin
from . import models


admin.site.register(models.Author1)
admin.site.register(models.Article)
# Register your models here.
