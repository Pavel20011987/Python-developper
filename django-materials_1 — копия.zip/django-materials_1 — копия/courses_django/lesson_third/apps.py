from django.apps import AppConfig


class LessonThirdConfig(AppConfig):
    name = 'lesson_third'
