from django.apps import AppConfig


class LessonEighthConfig(AppConfig):
    name = 'lesson_eighth'
