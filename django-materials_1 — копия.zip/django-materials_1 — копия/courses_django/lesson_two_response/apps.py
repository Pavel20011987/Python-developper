from django.apps import AppConfig


class LessonTwoResponseConfig(AppConfig):
    name = 'lesson_two_response'
