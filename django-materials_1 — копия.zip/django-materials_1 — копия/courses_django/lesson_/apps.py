from django.apps import AppConfig


class LessonConfig(AppConfig):
    name = 'lesson_'
