from django.apps import AppConfig


class LessonSeventhConfig(AppConfig):
    name = 'lesson_seventh'
