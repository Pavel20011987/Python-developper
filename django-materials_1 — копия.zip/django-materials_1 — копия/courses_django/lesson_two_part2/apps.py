from django.apps import AppConfig


class LessonTwoPart2Config(AppConfig):
    name = 'lesson_two_part2'
