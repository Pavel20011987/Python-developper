from django.apps import AppConfig


class LessonFourthConfig(AppConfig):
    name = 'lesson_fourth'
