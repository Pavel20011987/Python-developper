from django.apps import AppConfig


class LessonOneConfig(AppConfig):
    name = 'lesson_one'
