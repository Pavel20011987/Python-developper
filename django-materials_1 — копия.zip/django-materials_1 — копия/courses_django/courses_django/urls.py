"""courses_django URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
# from lesson_two import views

from . import settings

from django.conf.urls.static import static



urlpatterns = [

    url(r'^lesson-two-part2/' , include('lesson_two_part2.urls')),
    url(r'^admin-secure/', admin.site.urls),
    url(r'^', include('lesson_two.urls')),
    url(r'^lesson-two-response/', include('lesson_two_response.urls')),
    url(r'^lesson-third/', include('lesson_third.urls')),
    url(r'^lesson-fourth/', include('lesson_fourth.urls')),
    url(r'^lesson-fifth/', include('lesson_fifth.urls')),
    url(r'^lesson-sixth/', include('lesson_sixth.urls')),
    url(r'^lesson-seventh/', include('lesson_seventh.urls')),
    url(r'^lesson-eighth/', include('lesson_eighth.urls')),
    #url(r'^', views.home),   #localhost:5650

]

























# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



























'''
    Если требуется указать символы, которые не входят в указанный набор,
    то используют символ ^ внутри квадратных скобок,

    \d  == [0-9] == [1234567890]
    \D  == [^0-9]
    \s  == [\f\n\r\t]
    \S  == [^\f\n\r\t]
    \w  == [a-z_0-9]
    \W  == [^a-z_0-9]


'''
'''

    [абв], [1234567890] => [0-9]
    [а-я] - все малые буквы от а до я
    [А-Я] - все большие буквы от А до Я
    [А-Яа-я] => все буквы русского алфавита за исключением ё и Ё

    ^test  находит 'test' только если он в начале строки test_1
    test$     находит 'test' только если он в конце строки qwertytest
    ^test$   находит 'test' только если это единственное слово в строке




"Жадность регулярных выражений"
 b+ как и b*( abbbbc - > bbbb,
 b+? -> только b,
 а b*? -> пустую строку;
 b{2,3}? -> 'bb'
 b{2,3} найдет bbb.

'''